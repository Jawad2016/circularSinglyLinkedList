/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.circularsinglylinkedlist;

/**
 *
 * @author Jawad Royesh
 */
public class CircularSinglyLinkedList {
    Node last;

    public CircularSinglyLinkedList() {
        this.last = null;
    }
    
    public void insertFirst(int data){
    
        Node temp = new Node(data);
        
        if(last!= null){
        
            temp.next = last.next;
        }
        else {
        
            last = temp;
        
        }
        last.next =temp;
        
    
    }
    
    public void display(){
    
        Node first = last.next;
        while(first != last ){
        System.out.print(first.data + " ");
        first = first.next;
        }
        System.out.print(first.data + " ");
    }
  
}

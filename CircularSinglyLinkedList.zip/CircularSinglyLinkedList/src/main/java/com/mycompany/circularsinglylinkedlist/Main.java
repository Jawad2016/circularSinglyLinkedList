/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.circularsinglylinkedlist;

/**
 *
 * @author Jawad Royesh
 */
public class Main {
    
    public static void main(String[] args){
    
        CircularSinglyLinkedList list = new CircularSinglyLinkedList();
        list.insertFirst(34);
        list.insertFirst(56);
        list.insertFirst(45);
        list.display();
    
    }
}
